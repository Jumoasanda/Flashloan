import { useState, useEffect, useRef, useCallback } from "react";

// ─── Real pool addresses on Ethereum mainnet ────────────────────────────────
// Each token has its best pool on each DEX so we can compare real prices
const POOL_CONFIG = {
  "WETH/USDC": {
    token: "WETH",
    quote: "USDC",
    pools: {
      "Uniswap V3":  "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640", // WETH/USDC 0.05%
      "Uniswap V2":  "0xb4e16d0168e52d35cacd2c6185b44281ec28c9dc", // WETH/USDC V2
      "SushiSwap":   "0x397ff1542f962076d0bfe58ea045ffa2d347aca0", // WETH/USDC Sushi
      "Curve":       "0x7f86bf177dd4f3494b841a37e810a34dd56c829b", // TricryptoUSDC
    },
    loanAmt: 100000,
  },
  "WBTC/USDC": {
    token: "WBTC",
    quote: "USDC",
    pools: {
      "Uniswap V3":  "0x99ac8ca7087fa4a2a1fb6357269965a2014abc35", // WBTC/USDC 0.3%
      "Uniswap V2":  "0x004375dff511095cc5a197a54140a24efef3a416", // WBTC/USDC V2
      "SushiSwap":   "0xceff51756c56ceffca006cd410b03ffc46dd3a58", // WBTC/WETH Sushi (proxy)
    },
    loanAmt: 100000,
  },
  "LINK/ETH": {
    token: "LINK",
    quote: "ETH",
    pools: {
      "Uniswap V3":  "0xa6cc3c2531fdaa6ae1a3ca84c2855806728693e8", // LINK/WETH 0.3%
      "Uniswap V2":  "0xa2107fa5b38d9bbd2c461d6edf11b11a50f6b974", // LINK/WETH V2
      "SushiSwap":   "0xc40d16476380e4037e6b1a2594caf6a6cc8da967", // LINK/WETH Sushi
    },
    loanAmt: 50000,
  },
  "UNI/ETH": {
    token: "UNI",
    quote: "ETH",
    pools: {
      "Uniswap V3":  "0x1d42064fc4beb5f8aaf85f4617ae8b3b5b8bd801", // UNI/WETH 0.3%
      "Uniswap V2":  "0xd3d2e2692501a5c9ca623199d38826e513033a17", // UNI/WETH V2
      "SushiSwap":   "0xdafd66636e2561b0284edde37e42d192f2844d40", // UNI/WETH Sushi
    },
    loanAmt: 30000,
  },
  "DAI/USDC": {
    token: "DAI",
    quote: "USDC",
    pools: {
      "Uniswap V3":  "0x5777d92f208679db4b9778590fa3cab3ac9e2168", // DAI/USDC 0.01%
      "Uniswap V2":  "0xae461ca67b15dc8dc81ce7615e0320da1a9ab8d5", // DAI/USDC V2
      "Curve":       "0xbebc44782c7db0a1a60cb6fe97d0b483032ff1c7", // 3pool (DAI/USDC/USDT)
    },
    loanAmt: 500000,
  },
};

const FLASH_LOAN_FEE = 0.0009;
const GAS_COST_USD   = 18;
const GECKO_BASE     = "https://api.geckoterminal.com/api/v2";
const REFRESH_MS     = 30000; // GeckoTerminal free: ~10 req/min, so be respectful

const CHAIN_NAMES = {
  "0x1": "Ethereum Mainnet",
  "0xaa36a7": "Sepolia Testnet",
  "0x89": "Polygon",
  "0xa4b1": "Arbitrum One",
  "0x2105": "Base",
  "0xa": "Optimism",
};

const DEX_COLORS = {
  "Uniswap V3": "#FF007A",
  "Uniswap V2": "#FF6FAE",
  SushiSwap:    "#03B5C5",
  Curve:        "#3355FF",
  Balancer:     "#9945FF",
};

// ─── GeckoTerminal fetcher ────────────────────────────────────────────────────
async function fetchPoolPrices(pairKey) {
  const cfg    = POOL_CONFIG[pairKey];
  const addrs  = Object.values(cfg.pools).join(",");
  const dexes  = Object.keys(cfg.pools);
  const url    = `${GECKO_BASE}/networks/eth/pools/multi/${addrs}?include=base_token,quote_token`;
  const res    = await fetch(url, { headers: { Accept: "application/json;version=20230302" } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json   = await res.json();

  // Build a map of pool address → price
  const priceByAddr = {};
  (json.data || []).forEach(pool => {
    const addr  = pool.attributes.address?.toLowerCase();
    const price = parseFloat(pool.attributes.base_token_price_usd);
    if (addr && !isNaN(price)) priceByAddr[addr] = price;
  });

  // Match back to DEX names
  const result = {};
  dexes.forEach(dex => {
    const addr  = cfg.pools[dex].toLowerCase();
    const price = priceByAddr[addr];
    if (price && price > 0) result[dex] = price;
  });
  return result;
}

function calcArbitrage(pairKey, dexPrices) {
  const cfg    = POOL_CONFIG[pairKey];
  const entries = Object.entries(dexPrices).filter(([, p]) => p > 0);
  if (entries.length < 2) return null;

  entries.sort((a, b) => a[1] - b[1]);
  const [buyDex, buyPrice]   = entries[0];
  const [sellDex, sellPrice] = entries[entries.length - 1];

  const spreadPct  = ((sellPrice - buyPrice) / buyPrice) * 100;
  const units      = cfg.loanAmt / buyPrice;
  const gross      = units * (sellPrice - buyPrice);
  const fee        = cfg.loanAmt * FLASH_LOAN_FEE;
  const net        = gross - fee - GAS_COST_USD;

  return {
    pair: pairKey,
    token: cfg.token,
    quote: cfg.quote,
    buyDex, sellDex, buyPrice, sellPrice,
    spreadPct, loanAmt: cfg.loanAmt, gross, fee, net,
    viable: net > 0,
    allPrices: dexPrices,
  };
}

// ─── Sub-components ─────────────────────────────────────────────────────────

function Sparkline({ data, color }) {
  if (!data || data.length < 2) return <svg width={80} height={28} />;
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * 80;
    const y = 28 - ((v - min) / range) * 28;
    return `${x},${y}`;
  }).join(" ");
  return (
    <svg width={80} height={28}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.8" strokeLinejoin="round" />
    </svg>
  );
}

function PulsingDot({ color }) {
  return (
    <span style={{
      display: "inline-block", width: 7, height: 7, borderRadius: "50%",
      background: color, marginRight: 5,
      boxShadow: `0 0 6px ${color}`,
      animation: "pulse 1.5s infinite"
    }} />
  );
}

function ComboStep({ step, index, onRemove }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      background: "#0d1117", border: "1px solid #21262d",
      borderRadius: 10, padding: "10px 14px", marginBottom: 6
    }}>
      <div style={{
        width: 26, height: 26, borderRadius: "50%",
        background: DEX_COLORS[step.dex] || "#555",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 11, fontWeight: 700, color: "#fff", flexShrink: 0
      }}>{index + 1}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, color: "#8b949e", marginBottom: 1 }}>{step.action}</div>
        <div style={{ fontSize: 14, color: "#e6edf3", fontWeight: 600 }}>
          {step.token} <span style={{ color: "#484f58" }}>on</span> {step.dex}
        </div>
      </div>
      <div style={{ textAlign: "right", fontSize: 12, color: "#3fb950" }}>{step.amount}</div>
      <button onClick={() => onRemove(index)} style={{
        background: "none", border: "none", color: "#484f58",
        cursor: "pointer", fontSize: 18, lineHeight: 1, padding: "0 4px"
      }}>×</button>
    </div>
  );
}

// ─── Main App ────────────────────────────────────────────────────────────────
export default function App() {
  const [liveData,     setLiveData]     = useState({});   // pairKey → { dex → price }
  const [opportunities, setOpportunities] = useState([]);
  const [priceHistory, setPriceHistory]  = useState({});  // pairKey → [avg prices]
  const [loading,      setLoading]       = useState(true);
  const [error,        setError]         = useState(null);
  const [lastUpdate,   setLastUpdate]    = useState(null);
  const [countdown,    setCountdown]     = useState(REFRESH_MS / 1000);
  const [tab,          setTab]           = useState("opportunities");
  const [selectedOpp,  setSelectedOpp]   = useState(null);
  const [comboSteps,   setComboSteps]    = useState([]);
  const [executing,    setExecuting]     = useState(false);
  const [execResult,   setExecResult]    = useState(null);
  const [log,          setLog]           = useState([]);
  const logRef = useRef(null);
  const timerRef = useRef(null);

  // ── Wallet (MetaMask) state ─────────────────────────────────────────────
  const [account,     setAccount]     = useState(null);   // connected address
  const [chainId,     setChainId]     = useState(null);
  const [balanceEth,  setBalanceEth]  = useState(null);
  const [connecting,  setConnecting]  = useState(false);
  const [walletError, setWalletError] = useState(null);

  const addLog = (msg, type = "info") =>
    setLog(prev => [...prev.slice(-49), { msg, type, ts: new Date().toLocaleTimeString() }]);

  // ── Fetch all pairs from GeckoTerminal ──────────────────────────────────
  const fetchAll = useCallback(async () => {
    setError(null);
    try {
      const pairs = Object.keys(POOL_CONFIG);
      // Batch with small delay to respect rate limit
      const results = {};
      for (let i = 0; i < pairs.length; i++) {
        if (i > 0) await new Promise(r => setTimeout(r, 1200));
        try {
          results[pairs[i]] = await fetchPoolPrices(pairs[i]);
        } catch (e) {
          results[pairs[i]] = liveData[pairs[i]] || {};
        }
      }

      setLiveData(results);
      setLastUpdate(new Date());
      setLoading(false);
      setCountdown(REFRESH_MS / 1000);

      // Calculate opportunities
      const opps = pairs
        .map(pk => calcArbitrage(pk, results[pk] || {}))
        .filter(Boolean)
        .sort((a, b) => b.net - a.net);
      setOpportunities(opps);

      // Price history (track avg price per pair)
      setPriceHistory(prev => {
        const next = { ...prev };
        pairs.forEach(pk => {
          const vals = Object.values(results[pk] || {}).filter(v => v > 0);
          if (vals.length) {
            const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
            next[pk] = [...(next[pk] || []).slice(-19), avg];
          }
        });
        return next;
      });
    } catch (e) {
      setError("Failed to fetch live data. GeckoTerminal may be rate-limiting. Retrying…");
      setLoading(false);
    }
  }, [liveData]);

  // Initial fetch + interval
  useEffect(() => {
    fetchAll();
    const interval = setInterval(fetchAll, REFRESH_MS);
    return () => clearInterval(interval);
  }, []);

  // Countdown ticker
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setCountdown(c => Math.max(0, c - 1));
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, []);

  useEffect(() => {
    if (lastUpdate) setCountdown(REFRESH_MS / 1000);
  }, [lastUpdate]);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [log]);

  // ── Combo builder ─────────────────────────────────────────────────────────
  function loadCombo(opp) {
    setSelectedOpp(opp);
    setComboSteps([
      { action: "Flash Loan (Aave V3)", dex: "Aave", token: `${opp.pair}`, amount: `$${opp.loanAmt.toLocaleString()} USDC` },
      { action: "Buy (swap)", dex: opp.buyDex,  token: opp.token, amount: `@ $${opp.buyPrice.toFixed(4)}` },
      { action: "Sell (swap)", dex: opp.sellDex, token: opp.token, amount: `@ $${opp.sellPrice.toFixed(4)}` },
      { action: "Repay Loan + Fee", dex: "Aave", token: "USDC", amount: `-$${(opp.loanAmt + opp.fee).toFixed(2)}` },
    ]);
    setTab("combo");
    setExecResult(null);
  }

  const removeStep = i => setComboSteps(prev => prev.filter((_, idx) => idx !== i));

  async function executeCombo() {
    if (!selectedOpp || comboSteps.length < 4) return;
    setExecuting(true);
    setExecResult(null);
    addLog("Initiating flash loan sequence on Ethereum mainnet…", "info");
    await delay(700);
    addLog(`Aave V3: Flash loan requested — $${selectedOpp.loanAmt.toLocaleString()} USDC`, "info");
    await delay(900);
    addLog(`${selectedOpp.buyDex}: Swap USDC → ${selectedOpp.token} @ $${selectedOpp.buyPrice.toFixed(4)} (live price)`, "info");
    await delay(800);
    addLog(`${selectedOpp.sellDex}: Swap ${selectedOpp.token} → USDC @ $${selectedOpp.sellPrice.toFixed(4)} (live price)`, "info");
    await delay(600);
    addLog(`Aave V3: Repaying $${(selectedOpp.loanAmt + selectedOpp.fee).toFixed(2)} USDC (loan + 0.09% fee)`, "info");
    await delay(500);
    if (selectedOpp.viable) {
      addLog(`✅ Simulation complete. Est. net profit: +$${selectedOpp.net.toFixed(2)} USDC`, "success");
      setExecResult({ success: true, profit: selectedOpp.net });
    } else {
      addLog(`⚠️ Trade would result in a loss (-$${Math.abs(selectedOpp.net).toFixed(2)}). Combo aborted.`, "warn");
      setExecResult({ success: false, loss: selectedOpp.net });
    }
    setExecuting(false);
  }

  function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ── MetaMask connection (read-only: address / network / balance) ───────────
  // Note: this does NOT send any transaction. "Execute Combo" above remains a
  // pure client-side simulation — no real swaps, loans, or transfers happen.
  const fetchBalance = useCallback(async (addr, provider) => {
    try {
      const hexBal = await provider.request({
        method: "eth_getBalance",
        params: [addr, "latest"],
      });
      const wei = BigInt(hexBal);
      const eth = Number(wei) / 1e18;
      setBalanceEth(eth);
    } catch (e) {
      setBalanceEth(null);
    }
  }, []);

  const connectWallet = useCallback(async () => {
    setWalletError(null);
    if (typeof window === "undefined" || !window.ethereum) {
      setWalletError("No wallet extension detected. Install MetaMask to connect.");
      return;
    }
    setConnecting(true);
    try {
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
      const cid = await window.ethereum.request({ method: "eth_chainId" });
      setAccount(accounts[0] || null);
      setChainId(cid);
      if (accounts[0]) await fetchBalance(accounts[0], window.ethereum);
      addLog(`Wallet connected: ${accounts[0]}`, "success");
    } catch (e) {
      setWalletError(e?.message || "Connection request was rejected.");
    } finally {
      setConnecting(false);
    }
  }, [fetchBalance]);

  const disconnectWallet = () => {
    setAccount(null);
    setBalanceEth(null);
    setChainId(null);
    addLog("Wallet disconnected (local UI state only — MetaMask stays connected until revoked in the extension).", "info");
  };

  // React to account/network switches made inside MetaMask itself
  useEffect(() => {
    if (typeof window === "undefined" || !window.ethereum) return;
    const onAccountsChanged = (accounts) => {
      setAccount(accounts[0] || null);
      if (accounts[0]) fetchBalance(accounts[0], window.ethereum);
      else setBalanceEth(null);
    };
    const onChainChanged = (cid) => {
      setChainId(cid);
      if (account) fetchBalance(account, window.ethereum);
    };
    window.ethereum.on?.("accountsChanged", onAccountsChanged);
    window.ethereum.on?.("chainChanged", onChainChanged);
    return () => {
      window.ethereum.removeListener?.("accountsChanged", onAccountsChanged);
      window.ethereum.removeListener?.("chainChanged", onChainChanged);
    };
  }, [account, fetchBalance]);

  const logColors = { info: "#8b949e", success: "#3fb950", warn: "#d29922", error: "#f85149" };

  const viableCount  = opportunities.filter(o => o.viable).length;
  const bestOpp      = opportunities[0];

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: "100vh", background: "#010409", color: "#e6edf3",
      fontFamily: "'JetBrains Mono','Fira Code','Courier New',monospace" }}>

      <style>{`
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.25} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(4px)} to{opacity:1;transform:translateY(0)} }
        @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        .card:hover { border-color:#7c3aed !important; transform:translateY(-1px); box-shadow:0 0 20px #7c3aed18; }
        .tab-btn:hover { color:#e6edf3 !important; }
      `}</style>

      {/* ── Header ── */}
      <div style={{ background:"#0d1117", borderBottom:"1px solid #21262d",
        padding:"13px 24px", display:"flex", alignItems:"center", justifyContent:"space-between",
        position:"sticky", top:0, zIndex:100 }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ width:34, height:34, borderRadius:9,
            background:"linear-gradient(135deg,#7c3aed,#2563eb)",
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>⚡</div>
          <div>
            <div style={{ fontSize:15, fontWeight:700, letterSpacing:"-0.3px" }}>ArbScan <span style={{ fontSize:11, color:"#7c3aed", fontWeight:400 }}>LIVE</span></div>
            <div style={{ fontSize:11, color:"#484f58" }}>Real on-chain DEX prices via GeckoTerminal</div>
          </div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:18, fontSize:12 }}>
          {loading ? (
            <div style={{ color:"#d29922" }}>
              <span style={{ display:"inline-block", animation:"spin 1s linear infinite", marginRight:5 }}>⟳</span>
              Fetching live data…
            </div>
          ) : error ? (
            <div style={{ color:"#f85149", maxWidth:260 }}>{error}</div>
          ) : (
            <div style={{ color:"#484f58" }}>
              <PulsingDot color="#3fb950" />
              Updated {lastUpdate?.toLocaleTimeString()} · next in <span style={{ color:"#e6edf3" }}>{countdown}s</span>
            </div>
          )}
          <button onClick={fetchAll} style={{
            background:"#161b22", border:"1px solid #30363d", borderRadius:6,
            color:"#e6edf3", cursor:"pointer", fontSize:12, padding:"5px 12px", fontFamily:"inherit"
          }}>↻ Refresh</button>

          {account ? (
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <div style={{
                background:"#0f2a1b", border:"1px solid #1f6a3a", borderRadius:6,
                padding:"5px 10px", fontSize:11, color:"#3fb950", display:"flex",
                flexDirection:"column", alignItems:"flex-end", lineHeight:1.3
              }}>
                <span>{account.slice(0,6)}…{account.slice(-4)} · {CHAIN_NAMES[chainId] || chainId || "unknown network"}</span>
                <span style={{ color:"#7d8590" }}>{balanceEth != null ? `${balanceEth.toFixed(4)} ETH` : ""}</span>
              </div>
              <button onClick={disconnectWallet} style={{
                background:"#161b22", border:"1px solid #30363d", borderRadius:6,
                color:"#8b949e", cursor:"pointer", fontSize:11, padding:"5px 10px", fontFamily:"inherit"
              }}>Disconnect</button>
            </div>
          ) : (
            <button onClick={connectWallet} disabled={connecting} style={{
              background: connecting ? "#161b22" : "linear-gradient(135deg,#7c3aed,#2563eb)",
              border:"none", borderRadius:6, color:"#fff", cursor: connecting ? "not-allowed" : "pointer",
              fontSize:12, padding:"6px 14px", fontFamily:"inherit", fontWeight:600
            }}>{connecting ? "Connecting…" : "🦊 Connect Wallet"}</button>
          )}
        </div>
      </div>

      {walletError && (
        <div style={{ background:"#2a0f0f", borderBottom:"1px solid #6a1f1f", color:"#f85149",
          fontSize:12, padding:"8px 24px" }}>
          {walletError}
        </div>
      )}

      {/* ── Stats bar ── */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)",
        gap:1, background:"#21262d", borderBottom:"1px solid #21262d" }}>
        {[
          { label:"Pairs Tracked",   value:Object.keys(POOL_CONFIG).length, sub:"Ethereum mainnet" },
          { label:"Viable Trades",   value:loading ? "…" : viableCount, sub:"net positive after fees", color:"#3fb950" },
          { label:"Best Spread",     value:loading ? "…" : bestOpp ? `${bestOpp.spreadPct.toFixed(4)}%` : "—", sub:bestOpp?.pair || "scanning" },
          { label:"Est. Net Profit", value:loading ? "…" : bestOpp ? `$${bestOpp.net.toFixed(2)}` : "—",
            sub:"top opportunity", color: bestOpp?.net > 0 ? "#3fb950" : "#f85149" },
        ].map(s => (
          <div key={s.label} style={{ background:"#0d1117", padding:"14px 20px" }}>
            <div style={{ fontSize:11, color:"#484f58", marginBottom:4, textTransform:"uppercase", letterSpacing:"0.5px" }}>{s.label}</div>
            <div style={{ fontSize:22, fontWeight:700, color:s.color || "#e6edf3" }}>{s.value}</div>
            <div style={{ fontSize:11, color:"#30363d" }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* ── Tabs ── */}
      <div style={{ display:"flex", borderBottom:"1px solid #21262d", background:"#0d1117", padding:"0 24px" }}>
        {["opportunities","combo","prices","log"].map(t => (
          <button key={t} className="tab-btn" onClick={() => setTab(t)} style={{
            background:"none", border:"none",
            borderBottom: tab===t ? "2px solid #7c3aed" : "2px solid transparent",
            color: tab===t ? "#e6edf3" : "#484f58",
            cursor:"pointer", fontFamily:"inherit", fontSize:13,
            padding:"12px 16px", marginBottom:-1,
            textTransform:"capitalize", fontWeight: tab===t ? 600 : 400
          }}>
            {t==="combo" ? "⚡ Combo Builder" : t.charAt(0).toUpperCase()+t.slice(1)}
          </button>
        ))}
      </div>

      <div style={{ padding:"20px 24px", maxWidth:1100, margin:"0 auto" }}>

        {/* ── Opportunities ── */}
        {tab==="opportunities" && (
          <div>
            <div style={{ fontSize:12, color:"#484f58", marginBottom:16 }}>
              Prices sourced from GeckoTerminal on-chain data · Loan sizes vary by pair · Aave fee 0.09% · Gas ~${GAS_COST_USD}
            </div>

            {loading && (
              <div style={{ textAlign:"center", padding:60, color:"#484f58" }}>
                <div style={{ fontSize:28, marginBottom:10, animation:"spin 1.5s linear infinite", display:"inline-block" }}>⟳</div>
                <div>Fetching real DEX prices from Ethereum mainnet…</div>
                <div style={{ fontSize:11, marginTop:8, color:"#30363d" }}>This takes ~{Object.keys(POOL_CONFIG).length * 1.2}s due to rate limits</div>
              </div>
            )}

            {!loading && (
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(320px,1fr))", gap:12 }}>
                {opportunities.map(opp => (
                  <div key={opp.pair} className="card" onClick={() => loadCombo(opp)} style={{
                    background:"#0d1117",
                    border:`1px solid ${opp.viable ? "#21262d" : "#2a1010"}`,
                    borderRadius:12, padding:16, cursor:"pointer",
                    transition:"all 0.15s", animation:"fadeIn 0.3s ease"
                  }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:12 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                        <div style={{ background:"#161b22", borderRadius:8, padding:"4px 10px",
                          fontSize:13, fontWeight:700 }}>{opp.pair}</div>
                        <div style={{
                          fontSize:10, padding:"3px 8px", borderRadius:20,
                          background: opp.viable ? "#0f2a1b" : "#2a0f0f",
                          color: opp.viable ? "#3fb950" : "#f85149",
                          border:`1px solid ${opp.viable ? "#1f6a3a" : "#6a1f1f"}`
                        }}>
                          {opp.viable ? "VIABLE" : "MARGINAL"}
                        </div>
                      </div>
                      <Sparkline data={priceHistory[opp.pair]} color={opp.viable ? "#3fb950" : "#484f58"} />
                    </div>

                    <div style={{ display:"flex", gap:8, marginBottom:12 }}>
                      {[
                        { label:"BUY ON", dex:opp.buyDex,  price:opp.buyPrice },
                        { label:"SELL ON", dex:opp.sellDex, price:opp.sellPrice },
                      ].map(side => (
                        <div key={side.label} style={{ flex:1,
                          background:`${DEX_COLORS[side.dex] || "#333"}11`,
                          borderRadius:8, padding:"8px 10px",
                          border:`1px solid ${DEX_COLORS[side.dex] || "#333"}33`
                        }}>
                          <div style={{ fontSize:10, color:"#484f58", marginBottom:2 }}>{side.label}</div>
                          <div style={{ fontSize:11, color:DEX_COLORS[side.dex] || "#e6edf3", fontWeight:600 }}>{side.dex}</div>
                          <div style={{ fontSize:13, color:"#e6edf3", marginTop:2 }}>
                            ${side.price < 10 ? side.price.toFixed(5) : side.price < 1000 ? side.price.toFixed(3) : side.price.toFixed(2)}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
                      {[
                        { l:"Spread",    v:`${opp.spreadPct.toFixed(4)}%`, c:"#e6edf3" },
                        { l:"Gross",     v:`$${opp.gross.toFixed(2)}`,      c:"#e6edf3" },
                        { l:"Net",       v:`${opp.net>0?"+":""}$${opp.net.toFixed(2)}`, c:opp.net>0?"#3fb950":"#f85149" },
                      ].map(s => (
                        <div key={s.l} style={{ background:"#161b22", borderRadius:6, padding:"6px 8px" }}>
                          <div style={{ fontSize:10, color:"#484f58" }}>{s.l}</div>
                          <div style={{ fontSize:13, fontWeight:600, color:s.c }}>{s.v}</div>
                        </div>
                      ))}
                    </div>

                    <div style={{ marginTop:10, fontSize:10, color:"#30363d", textAlign:"right" }}>
                      Loan: ${opp.loanAmt.toLocaleString()} · Click to build combo →
                    </div>
                  </div>
                ))}

                {opportunities.length === 0 && !loading && (
                  <div style={{ gridColumn:"1/-1", textAlign:"center", padding:60, color:"#484f58" }}>
                    <div style={{ fontSize:28 }}>🔍</div>
                    No opportunities detected. Prices may be too tightly spread right now.
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ── Combo Builder ── */}
        {tab==="combo" && (
          <div style={{ display:"grid", gridTemplateColumns:"1fr 300px", gap:20 }}>
            <div>
              <div style={{ fontSize:12, color:"#484f58", marginBottom:14 }}>
                {selectedOpp ? `Combo: ${selectedOpp.pair} · ${selectedOpp.buyDex} → ${selectedOpp.sellDex}` : "Load a live opportunity to build a combo"}
              </div>

              {comboSteps.length === 0 ? (
                <div style={{ background:"#0d1117", border:"1px dashed #21262d",
                  borderRadius:12, padding:48, textAlign:"center", color:"#484f58" }}>
                  <div style={{ fontSize:28, marginBottom:10 }}>⚡</div>
                  Go to <strong style={{ color:"#7d8590" }}>Opportunities</strong> and click a card.
                </div>
              ) : (
                <div>
                  {comboSteps.map((step, i) => (
                    <ComboStep key={i} step={step} index={i} onRemove={removeStep} />
                  ))}

                  <div style={{ margin:"14px 0", padding:"12px 16px",
                    background:"#0d1117", borderRadius:10, border:"1px solid #21262d" }}>
                    {[
                      { l:"Flash loan amount",  v:`$${selectedOpp?.loanAmt.toLocaleString()}`,          c:"#e6edf3" },
                      { l:"Gross profit",        v:`$${selectedOpp?.gross.toFixed(2)}`,                  c:"#e6edf3" },
                      { l:"Aave fee (0.09%)",    v:`-$${selectedOpp?.fee.toFixed(2)}`,                   c:"#f85149" },
                      { l:"Est. gas",            v:`-$${GAS_COST_USD}.00`,                               c:"#f85149" },
                    ].map(r => (
                      <div key={r.l} style={{ display:"flex", justifyContent:"space-between",
                        fontSize:12, color:"#7d8590", marginBottom:5 }}>
                        <span>{r.l}</span><span style={{ color:r.c }}>{r.v}</span>
                      </div>
                    ))}
                    <div style={{ height:1, background:"#21262d", margin:"8px 0" }} />
                    <div style={{ display:"flex", justifyContent:"space-between", fontSize:14, fontWeight:700 }}>
                      <span>Net profit</span>
                      <span style={{ color:selectedOpp?.net>0?"#3fb950":"#f85149" }}>
                        {selectedOpp?.net>0?"+":""}${selectedOpp?.net.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <button onClick={executeCombo} disabled={executing} style={{
                    width:"100%", padding:"14px 0",
                    background:executing?"#161b22":"linear-gradient(135deg,#7c3aed,#2563eb)",
                    border:"none", borderRadius:10, color:"#fff", fontSize:14,
                    fontWeight:700, cursor:executing?"not-allowed":"pointer",
                    fontFamily:"inherit", transition:"opacity 0.2s"
                  }}>
                    {executing ? "⏳ Simulating execution…" : "⚡ Execute Combo (Simulation)"}
                  </button>

                  {execResult && (
                    <div style={{
                      marginTop:12, padding:"14px 16px", borderRadius:10,
                      background:execResult.success?"#0f2a1b":"#2a0f0f",
                      border:`1px solid ${execResult.success?"#1f6a3a":"#6a1f1f"}`,
                      color:execResult.success?"#3fb950":"#f85149",
                      fontSize:13, animation:"fadeIn 0.3s ease"
                    }}>
                      {execResult.success
                        ? `✅ Simulation successful. Est. net: +$${execResult.profit.toFixed(2)} USDC`
                        : `⚠️ Not profitable after fees. Loss: $${Math.abs(execResult.loss).toFixed(2)}. Combo not submitted.`}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Execution log */}
            <div>
              <div style={{ fontSize:11, color:"#484f58", marginBottom:8, textTransform:"uppercase", letterSpacing:"0.5px" }}>Log</div>
              <div ref={logRef} style={{
                background:"#010409", border:"1px solid #21262d", borderRadius:10,
                padding:12, height:360, overflowY:"auto", fontSize:11
              }}>
                {log.length === 0
                  ? <div style={{ color:"#30363d" }}>No activity yet.</div>
                  : log.map((l, i) => (
                    <div key={i} style={{ marginBottom:5, color:logColors[l.type] }}>
                      <span style={{ color:"#30363d" }}>[{l.ts}] </span>{l.msg}
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* ── Prices table ── */}
        {tab==="prices" && (
          <div>
            <div style={{ fontSize:12, color:"#484f58", marginBottom:14 }}>
              Live on-chain prices from GeckoTerminal pool data · 🟢 lowest · 🔴 highest per pair
            </div>
            {loading
              ? <div style={{ color:"#484f58", padding:40, textAlign:"center" }}>Loading live prices…</div>
              : Object.entries(POOL_CONFIG).map(([pair, cfg]) => {
                  const prices = liveData[pair] || {};
                  const vals   = Object.values(prices).filter(v => v > 0);
                  const min    = Math.min(...vals), max = Math.max(...vals);
                  return (
                    <div key={pair} style={{ marginBottom:20 }}>
                      <div style={{ fontSize:13, fontWeight:700, marginBottom:8, color:"#7d8590" }}>{pair}</div>
                      <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
                        {Object.entries(prices).map(([dex, price]) => (
                          <div key={dex} style={{
                            background:"#0d1117", borderRadius:8, padding:"10px 14px",
                            border:`1px solid ${price===min?"#1f6a3a":price===max?"#6a1f1f":"#21262d"}`,
                            minWidth:140
                          }}>
                            <div style={{ fontSize:11, color:DEX_COLORS[dex]||"#7d8590", marginBottom:3 }}>{dex}</div>
                            <div style={{ fontSize:15, fontWeight:700,
                              color:price===min?"#3fb950":price===max?"#f85149":"#e6edf3" }}>
                              ${price < 10 ? price.toFixed(6) : price < 1000 ? price.toFixed(4) : price.toFixed(2)}
                            </div>
                            {vals.length > 1 && (
                              <div style={{ fontSize:10, color:"#484f58", marginTop:2 }}>
                                {price===min?"▼ cheapest":price===max?"▲ priciest":""}
                              </div>
                            )}
                          </div>
                        ))}
                        {Object.keys(prices).length === 0 && (
                          <div style={{ color:"#484f58", fontSize:12 }}>No pool data returned for this pair.</div>
                        )}
                      </div>
                    </div>
                  );
                })
            }
            <div style={{ fontSize:11, color:"#30363d", marginTop:10 }}>
              Powered by GeckoTerminal Public API (api.geckoterminal.com) · No API key required
            </div>
          </div>
        )}

        {/* ── Log ── */}
        {tab==="log" && (
          <div>
            <div style={{ fontSize:12, color:"#484f58", marginBottom:14 }}>Full execution log</div>
            <div style={{ background:"#010409", border:"1px solid #21262d",
              borderRadius:10, padding:16, minHeight:300, fontSize:12 }}>
              {log.length === 0
                ? <div style={{ color:"#30363d" }}>No activity. Execute a combo to see logs here.</div>
                : [...log].reverse().map((l, i) => (
                  <div key={i} style={{ marginBottom:6, color:logColors[l.type] }}>
                    <span style={{ color:"#30363d" }}>[{l.ts}] </span>{l.msg}
                  </div>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
